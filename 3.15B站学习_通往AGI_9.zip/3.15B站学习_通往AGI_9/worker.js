addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request))
})

async function handleRequest(request) {
  // 处理CORS预检请求
  if (request.method === 'OPTIONS') {
    return new Response(null, {
      headers: getCorsHeaders()
    })
  }

  // 获取查询参数
  const url = new URL(request.url)
  const data = url.searchParams.get('data')
  if (!data) {
    return new Response('Missing data parameter', {
      status: 400,
      headers: getCorsHeaders()
    })
  }

  // 构建请求体
  const requestBody = {
    bot_id: '7485352795513274407',
    user_id: '123456789',
    stream: true,
    auto_save_history: true,
    additional_messages: [
      {
        role: 'user',
        content: data,
        content_type: 'text'
      }
    ]
  }

  try {
    // 发送请求到Coze API
    const response = await fetch('https://api.coze.cn/v3/chat', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer pat_RB5iZMEbRgGkSWWTt9LWwrFj6ubxrN2cUnnIwH1ud63FnRhMk6xKC7XPn0ZnB8hG',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    })

    // 创建TransformStream来处理流式响应
    const { readable, writable } = new TransformStream()
    response.body.pipeTo(writable)

    return new Response(readable, {
      headers: {
        ...getCorsHeaders(),
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive'
      }
    })
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: getCorsHeaders()
    })
  }
}

function getCorsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  }
}