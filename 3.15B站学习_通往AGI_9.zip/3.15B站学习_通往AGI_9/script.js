document.addEventListener('DOMContentLoaded', () => {
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');
    const resultDiv = document.getElementById('result');

    sendButton.addEventListener('click', async () => {
        const content = messageInput.value.trim();
        if (!content) {
            alert('请输入消息');
            return;
        }

        resultDiv.textContent = '正在获取响应...';
        sendButton.disabled = true;

        try {
            const response = await fetch(`https://ai-biaoqingbao.lizhengxuan1120.workers.dev/?data=${encodeURIComponent(content)}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            resultDiv.textContent = '';
            let buffer = '';



            while (true) {
                const {value, done} = await reader.read();
                if (done) break;
                
                buffer += decoder.decode(value);
                const events = buffer.split('\n\n');
                buffer = events.pop() || '';

                for (const event of events) {
                    if (!event.trim()) continue;
                    
                    const [eventLine, dataLine] = event.split('\n');
                    if (!eventLine.startsWith('event:') || !dataLine.startsWith('data:')) continue;

                    const eventType = eventLine.slice(6).trim();
                    const data = JSON.parse(dataLine.slice(5));

                    if (eventType === 'conversation.message.delta' && data.type === 'answer') {
                        if (data.content.startsWith('http') && (data.content.includes('.jpg') || data.content.includes('.png') || data.content.includes('.gif'))) {
                            const imgElement = document.createElement('img');
                            imgElement.src = data.content;
                            imgElement.className = 'result-image';
                            resultDiv.innerHTML = '';
                            resultDiv.appendChild(imgElement);
                        } else {
                            resultDiv.textContent = data.content;
                        }
                    }
                }
            }
        } catch (error) {
            resultDiv.textContent = `发生错误: ${error.message}`;
        } finally {
            sendButton.disabled = false;
        }
    });
});