// 获取DOM元素
const saveLinkButton = document.getElementById('saveLink');
const statusElement = document.getElementById('status');

// 更新状态显示
function updateStatus(message, type) {
  statusElement.textContent = message;
  statusElement.className = `status ${type}`;
}

// 获取当前标签页URL和域名
async function getCurrentTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const currentTab = tabs[0];
  const url = currentTab.url;
  const domain = new URL(url).hostname;
  return { url, domain };
}

// 保存链接到飞书多维表格
async function saveLink() {
  try {
    // 禁用按钮，显示加载状态
    saveLinkButton.disabled = true;
    updateStatus('正在保存链接...', 'loading');

    // 获取当前页面信息
    const { url, domain } = await getCurrentTab();

    // 发送消息给background script
    const result = await chrome.runtime.sendMessage({
      action: 'saveLink',
      url: url,
      displayText: domain
    });

    if (result.success) {
      updateStatus('链接保存成功！', 'success');
      // 3秒后关闭弹出窗口
      setTimeout(() => window.close(), 3000);
    } else {
      throw new Error(result.error || '保存失败');
    }
  } catch (error) {
    updateStatus(`错误：${error.message}`, 'error');
  } finally {
    // 重新启用按钮
    saveLinkButton.disabled = false;
  }
}

// 绑定点击事件
saveLinkButton.addEventListener('click', saveLink);