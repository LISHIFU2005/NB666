// 飞书API配置
const FEISHU_CONFIG = {
  appId: 'cli_a756a62c8ff8d013',
  appSecret: 'UHzJwdfCrJmeddgDytTUpfIeUj5PfvUM',
  baseId: 'Vf40baeQxaWgk8sRlbRcljqjnDe',
  tableId: 'tblpVKpdcGa2DcJL'
};

// 获取飞书访问令牌
async function getFeishuAccessToken() {
  try {
    const response = await fetch('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        'app_id': FEISHU_CONFIG.appId,
        'app_secret': FEISHU_CONFIG.appSecret
      })
    });

    const data = await response.json();
    if (data.code === 0) {
      return data.tenant_access_token;
    } else {
      throw new Error(`获取访问令牌失败：${data.msg}`);
    }
  } catch (error) {
    throw new Error(`获取访问令牌出错：${error.message}`);
  }
}

// 将链接保存到飞书多维表格
async function saveLinkToFeishu(url, displayText) {
  try {
    const accessToken = await getFeishuAccessToken();
    const response = await fetch(`https://open.feishu.cn/open-apis/bitable/v1/apps/${FEISHU_CONFIG.baseId}/tables/${FEISHU_CONFIG.tableId}/records`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        fields: {
          '链接': {
            'text': displayText,
            'link': url
          }
        }
      })
    });

    const data = await response.json();
    if (data.code === 0) {
      return { success: true };
    } else {
      throw new Error(data.msg);
    }
  } catch (error) {
    throw new Error(`保存链接失败：${error.message}`);
  }
}

// 监听来自popup的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'saveLink') {
    saveLinkToFeishu(request.url, request.displayText)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // 保持消息通道开放以支持异步响应
  }
});