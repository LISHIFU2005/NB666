const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');

const app = express();
app.use(cors());
app.use(express.json());

const API_KEY = 'e05a872f-0e9d-4458-b26b-b77c2751f677';
const API_URL = 'https://ark.cn-beijing.volces.com/api/v3/chat/completions';

app.post('/summarize', async (req, res) => {
  try {
    const { text } = req.body;
    
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`
      },
      body: JSON.stringify({
        model: 'deepseek-v3-241226',
        messages: [
          {
            role: 'system',
            content: '使用一个金句总结全文最核心的内容'
          },
          {
            role: 'user',
            content: text
          }
        ],
        temperature: 0.6,
        stream: true
      }),
      timeout: 60000
    });

    if (!response.ok) {
      throw new Error(`API request failed with status ${response.status}`);
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const reader = response.body.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      
      const chunk = decoder.decode(value);
      const lines = chunk.split('\n');
      
      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.slice(6);
          if (data === '[DONE]') continue;
          
          try {
            const parsed = JSON.parse(data);
            const content = parsed.choices[0].delta.content || '';
            res.write(`data: ${content}\n\n`);
          } catch (e) {
            console.error('Error parsing JSON:', e);
          }
        }
      }
    }
    
    res.end();
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});