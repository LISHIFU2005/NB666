// 获取DOM元素
const textInput = document.getElementById('text-input');
const fontSizeInput = document.getElementById('font-size');
const fontSizeValue = document.getElementById('font-size-value');
const paddingInput = document.getElementById('padding');
const paddingValue = document.getElementById('padding-value');
const previewBtn = document.getElementById('preview-btn');
const downloadBtn = document.getElementById('download-btn');
const previewContainer = document.getElementById('preview');
const styleCards = document.querySelectorAll('.style-card');

// 样式配置
const styles = {
  simple: {
    background: 'linear-gradient(120deg, #fdfbfb 0%, #ebedee 100%)',
    color: '#2c3e50',
    fontFamily: '"PingFang SC", "Microsoft YaHei", "Helvetica Neue", sans-serif',
    boxShadow: '0 4px 15px rgba(0,0,0,0.05)',
    letterSpacing: '0.5px'
  },
  warm: {
    background: 'linear-gradient(to right, #ffecd2 0%, #fcb69f 100%)',
    color: '#4a4a4a',
    fontFamily: '"Noto Serif SC", "Source Han Serif CN", "SimSun", serif',
    boxShadow: '0 4px 15px rgba(252,182,159,0.2)',
    letterSpacing: '1px'
  },
  dark: {
    background: 'linear-gradient(to right, #434343 0%, #000000 100%)',
    color: '#ffffff',
    fontFamily: '"Source Han Sans CN", "Microsoft YaHei", sans-serif',
    boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
    letterSpacing: '0.8px'
  },
  elegant: {
    background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
    color: '#34495e',
    fontFamily: '"FZQingKeBenYueSongS-R-GB", "STZhongsong", "Source Han Serif CN", serif',
    boxShadow: '0 4px 15px rgba(195,207,226,0.3)',
    letterSpacing: '1.2px'
  },
  nature: {
    background: 'linear-gradient(120deg, #84fab0 0%, #8fd3f4 100%)',
    color: '#1a5276',
    fontFamily: '"Source Han Sans CN", "Hiragino Sans GB", "Microsoft YaHei", sans-serif',
    boxShadow: '0 4px 15px rgba(132,250,176,0.2)',
    letterSpacing: '0.6px'
  }
};

// 当前选中的样式
let currentStyle = 'simple';

// 更新数值显示
fontSizeInput.addEventListener('input', () => {
  fontSizeValue.textContent = `${fontSizeInput.value}px`;
});

paddingInput.addEventListener('input', () => {
  paddingValue.textContent = `${paddingInput.value}px`;
});

// 样式选择
styleCards.forEach(card => {
  card.addEventListener('click', () => {
    styleCards.forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    currentStyle = card.dataset.style;
  });
});

// 生成预览图片
function generateImage() {
  const text = textInput.value.trim();
  if (!text) {
    alert('请输入文字内容');
    return null;
  }

  const fontSize = parseInt(fontSizeInput.value);
  const padding = parseInt(paddingInput.value);
  const align = document.querySelector('input[name="align"]:checked').value;
  const style = styles[currentStyle];

  // 创建canvas
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');

  // 设置canvas宽度
  const width = 400;
  canvas.width = width;

  // 设置字体和样式
  ctx.font = `${fontSize}px ${style.fontFamily}`;
  ctx.textAlign = align;
  ctx.fillStyle = style.background;

  // 计算文本换行
  const maxWidth = width - (padding * 2);
  const words = text.split('');
  const lines = [];
  let currentLine = '';

  for (let word of words) {
    const testLine = currentLine + word;
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxWidth && currentLine) {
      lines.push(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  }
  lines.push(currentLine);

  // 计算canvas高度
  const lineHeight = fontSize * 1.5;
  const height = (padding * 2) + (lines.length * lineHeight);
  canvas.height = height;

  // 绘制背景
  ctx.fillStyle = style.background;
  ctx.fillRect(0, 0, width, height);

  // 绘制文本
  ctx.fillStyle = style.color;
  ctx.font = `${fontSize}px ${style.fontFamily}`;
  ctx.textAlign = align;

  const textX = align === 'center' ? width / 2 : padding;
  let textY = padding + fontSize;

  lines.forEach(line => {
    ctx.fillText(line, textX, textY);
    textY += lineHeight;
  });

  return canvas;
}

// 预览按钮点击事件
previewBtn.addEventListener('click', () => {
  const canvas = generateImage();
  if (!canvas) return;

  // 清空预览区域
  previewContainer.innerHTML = '';
  previewContainer.appendChild(canvas);
});

// 总结按钮点击事件
const summarizeBtn = document.getElementById('summarize-btn');
summarizeBtn.addEventListener('click', async () => {
  const text = textInput.value.trim();
  if (!text) {
    alert('请输入文字内容');
    return;
  }

  summarizeBtn.disabled = true;
  summarizeBtn.textContent = '正在总结...';
  textInput.value = '';

  try {
    const response = await fetch('http://localhost:3000/summarize', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ text })
    });

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let summary = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      const lines = chunk.split('\n');

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const content = line.slice(6);
          summary += content;
          textInput.value = summary;
        }
      }
    }
  } catch (error) {
    console.error('Error:', error);
    alert('总结失败，请稍后重试');
  } finally {
    summarizeBtn.disabled = false;
    summarizeBtn.textContent = 'DeepSeek R1总结';
  }
});

// 下载按钮点击事件
downloadBtn.addEventListener('click', () => {
  const canvas = generateImage();
  if (!canvas) return;

  // 将canvas转换为图片并下载
  const link = document.createElement('a');
  link.download = '金句卡片.png';
  link.href = canvas.toDataURL('image/png');
  link.click();
});