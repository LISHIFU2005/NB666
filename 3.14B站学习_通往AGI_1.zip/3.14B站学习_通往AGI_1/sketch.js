let particles = [];
let attractors = [];
let time = 0;
let flowField = [];
let cols, rows;
let scl = 20;
let mouseAttractor = {
  pos: null,
  strength: 2,
  radius: 200
};

function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB, 360, 100, 100, 1);
  mouseAttractor.pos = createVector(mouseX, mouseY);
  
  // 初始化流场
  cols = floor(width / scl);
  rows = floor(height / scl);
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      flowField.push(createVector(0, 0));
    }
  }
  
  // 创建多个吸引子
  for (let i = 0; i < 5; i++) {
    attractors.push({
      pos: createVector(random(width), random(height)),
      strength: random(0.5, 2),
      radius: random(100, 300)
    });
  }
  
  // 初始化粒子系统
  for (let i = 0; i < 500; i++) {
    particles.push({
      pos: createVector(random(width), random(height)),
      vel: createVector(0, 0),
      acc: createVector(0, 0),
      color: color(random(360), 80, 90, 0.6),
      size: random(2, 6),
      maxSpeed: random(2, 5)
    });
  }
}

function draw() {
  background(0, 0, 10, 0.1);
  
  time += 0.01;
  
  // 更新鼠标吸引子位置
  mouseAttractor.pos.x = mouseX;
  mouseAttractor.pos.y = mouseY;
  
  // 更新流场
  let yoff = 0;
  for (let y = 0; y < rows; y++) {
    let xoff = 0;
    for (let x = 0; x < cols; x++) {
      let index = x + y * cols;
      let angle = noise(xoff, yoff, time * 0.3) * TWO_PI * 4;
      let v = p5.Vector.fromAngle(angle);
      v.setMag(1);
      flowField[index] = v;
      xoff += 0.1;
    }
    yoff += 0.1;
  }
  
  // 更新吸引子位置
  attractors.forEach((a, index) => {
    let angle = time + index * TWO_PI / attractors.length;
    a.pos.x = width/2 + cos(angle) * a.radius;
    a.pos.y = height/2 + sin(angle * 1.5) * a.radius;
    
    // 绘制吸引子及其影响范围
    noFill();
    stroke(index * 72, 80, 100, 0.3);
    circle(a.pos.x, a.pos.y, 20);
    circle(a.pos.x, a.pos.y, a.radius * 2);
  });
  
  // 绘制鼠标吸引子影响范围
  noFill();
  stroke(0, 0, 100, 0.3);
  circle(mouseAttractor.pos.x, mouseAttractor.pos.y, mouseAttractor.radius * 2);
  
  // 更新和绘制粒子
  for (let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i];
    
    // 应用流场力
    let x = floor(p.pos.x / scl);
    let y = floor(p.pos.y / scl);
    let index = x + y * cols;
    if (x >= 0 && x < cols && y >= 0 && y < rows) {
      let force = flowField[index].copy();
      force.mult(0.1);
      p.acc.add(force);
    }
    
    // 应用吸引子力
    attractors.forEach(a => {
      let force = p5.Vector.sub(a.pos, p.pos);
      let d = force.mag();
      if (d < a.radius) {
        force.normalize();
        force.mult(a.strength * (1 - d/a.radius));
        p.acc.add(force);
      }
    });
    
    // 应用鼠标吸引力
    let mouseForce = p5.Vector.sub(mouseAttractor.pos, p.pos);
    let d = mouseForce.mag();
    if (d < mouseAttractor.radius) {
      mouseForce.normalize();
      mouseForce.mult(mouseAttractor.strength * (1 - d/mouseAttractor.radius));
      p.acc.add(mouseForce);
    }
    
    // 更新运动
    p.vel.add(p.acc);
    p.vel.limit(p.maxSpeed);
    p.pos.add(p.vel);
    p.acc.mult(0);
    // 边界检查和重置位置
    if (p.pos.x < 0) p.pos.x = width;
    if (p.pos.x > width) p.pos.x = 0;
    if (p.pos.y < 0) p.pos.y = height;
    if (p.pos.y > height) p.pos.y = 0;
    
    // 绘制粒子
    fill(p.color);
    noStroke();
    circle(p.pos.x, p.pos.y, p.size);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  // 重新初始化流场
  cols = floor(width / scl);
  rows = floor(height / scl);
  flowField = [];
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      flowField.push(createVector(0, 0));
    }
  }
}