// 常量定义
const API_ENDPOINTS = {
    TEXT: 'https://api.minimax.chat/v1/text/chat/completions',
    VOICE: 'https://api.minimax.chat/v1/t2a_v2'
};

const API_KEY = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJHcm91cE5hbWUiOiJMSVNISUZVIiwiVXNlck5hbWUiOiJMSVNISUZVIiwiQWNjb3VudCI6IiIsIlN1YmplY3RJRCI6IjE5MDI5MTU1NjIzNDY5MjIyNzEiLCJQaG9uZSI6IjEzMzEzMTMxNjY0IiwiR3JvdXBJRCI6IjE5MDI5MTU1NjIzNDI3Mjc5NjciLCJQYWdlTmFtZSI6IiIsIk1haWwiOiIiLCJDcmVhdGVUaW1lIjoiMjAyNS0wMy0yMSAyMzo1NjoxNSIsIlRva2VuVHlwZSI6MSwiaXNzIjoibWluaW1heCJ9.P8f7xt_dtjXmUMeO0kif34rQyyiOFb7iJwCnAqGBUHWnLaChDthrJNQgE_ZbClW8q7II0B94nkWlivUW-1sM8M0b14A3GcVOFETfBVBWENMUZhlikGltrZnEksTM3gVhrYnVdCMTOzmKYVjowelGJpEaCz-lNvyFpkTT3KcLiutRL6f8npPRN61rOcnvf5NEGcF62rW9T3gcf7b0TL2GNwgJMMz-wKV43gxAyicgcG8egd3JmNtCELUPVKtJ0Y-ruzG7IXBRRpls2HS2jSMKpWLLuL_IWzzqR2q94-x2y9GbQGIP1eYcabu2lFr_DCpMciqwIGApcbwdjZpZBQyebA';
const GROUP_ID = '1902915562342727967';

// 默认系统提示词
const DEFAULT_SYSTEM_PROMPT = `你是一档名为《降噪》的AI科技广播节目的资深编辑，名字叫AI产品黄叔，擅长将专业的AI文章转化为通俗易懂的广播内容。请将以下原始内容改写成适合播报的稿件。

要求：
1. 请先全面的阅读一遍所有的新闻
2. 使用AI产品黄叔的身份，用幽默风趣的大白话，给AI小白讲清楚最新的资讯
3. 开场先概要说说今天发生了哪些大事
4. 每个新闻控制在100字以内，确保听众能在短时间内抓住重点
5. 语言风格要求：
   - 用生动的口语化表达，用大白话讲出专业性
   - 适当使用语气词增加自然感（比如"嗯"、"那么"、"其实"等）
   - 避免过于口语化的方言用语
   - 像跟朋友聊天一样轻松自然
6. 在保持通俗易懂的同时，准确传达AI技术的关键概念
7. 适当增加转场语，使话题之间衔接自然`;

// DOM 元素
const elements = {
    promptToggle: document.getElementById('promptToggle'),
    promptContent: document.getElementById('promptContent'),
    systemPrompt: document.getElementById('systemPrompt'),
    savePrompt: document.getElementById('savePrompt'),
    resetPrompt: document.getElementById('resetPrompt'),
    inputText: document.getElementById('inputText'),
    outputText: document.getElementById('outputText'),
    generateBtn: document.getElementById('generateBtn'),
    clearInput: document.getElementById('clearInput'),
    clearOutput: document.getElementById('clearOutput'),
    copyOutput: document.getElementById('copyOutput'),
    speed: document.getElementById('speed'),
    volume: document.getElementById('volume'),
    pitch: document.getElementById('pitch'),
    emotion: document.getElementById('emotion'),
    generateAudio: document.getElementById('generateAudio'),
    downloadAudio: document.getElementById('downloadAudio'),
    audioPlayer: document.getElementById('audioPlayer')
};

// 工具函数
const utils = {
    // 显示Toast提示
    showToast: (message, type = 'info') => {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        document.querySelector('.toast-container').appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    },
    
    // 设置加载状态
    setLoading: (element, isLoading) => {
        if (isLoading) {
            element.classList.add('is-loading');
            element.disabled = true;
        } else {
            element.classList.remove('is-loading');
            element.disabled = false;
        }
    },
    
    // 复制文本到剪贴板
    copyToClipboard: async (text) => {
        try {
            await navigator.clipboard.writeText(text);
            utils.showToast('复制成功');
        } catch (err) {
            utils.showToast('复制失败', 'error');
        }
    },
    
    // 保存文件
    saveFile: (blob, filename) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
    }
};

// 系统提示词管理
const promptManager = {
    init: () => {
        // 从localStorage加载保存的提示词
        const savedPrompt = localStorage.getItem('systemPrompt');
        elements.systemPrompt.value = savedPrompt || DEFAULT_SYSTEM_PROMPT;
        
        // 绑定事件
        elements.promptToggle.addEventListener('click', () => {
            elements.promptContent.classList.toggle('show');
            const icon = elements.promptToggle.querySelector('i');
            icon.classList.toggle('bi-chevron-right');
            icon.classList.toggle('bi-chevron-down');
        });
        
        elements.savePrompt.addEventListener('click', () => {
            localStorage.setItem('systemPrompt', elements.systemPrompt.value);
            utils.showToast('提示词已保存');
        });
        
        elements.resetPrompt.addEventListener('click', () => {
            elements.systemPrompt.value = DEFAULT_SYSTEM_PROMPT;
            localStorage.removeItem('systemPrompt');
            utils.showToast('提示词已重置');
        });
    }
};

// AI文本处理
const textProcessor = {
    // 生成广播稿
    generate: async () => {
        const inputText = elements.inputText.value.trim();
        if (!inputText) {
            utils.showToast('请输入需要转换的文章', 'warning');
            return;
        }
        
        utils.setLoading(elements.generateBtn, true);
        
        try {
            const response = await fetch(API_ENDPOINTS.TEXT, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'MiniMax-Text-01',
                    messages: [
                        {
                            role: 'system',
                            content: elements.systemPrompt.value
                        },
                        {
                            role: 'user',
                            content: inputText
                        }
                    ]
                })
            });
            
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || '生成失败');
            
            elements.outputText.value = data.choices[0].message.content;
            utils.showToast('广播稿生成成功');
            
        } catch (err) {
            utils.showToast(err.message || '生成失败', 'error');
        } finally {
            utils.setLoading(elements.generateBtn, false);
        }
    }
};

// 语音合成
const speechSynthesizer = {
    audioBlob: null,
    
    // 生成语音
    generate: async () => {
        const text = elements.outputText.value.trim();
        if (!text) {
            utils.showToast('请先生成广播稿', 'warning');
            return;
        }
        
        utils.setLoading(elements.generateAudio, true);
        
        try {
            const response = await fetch(`${API_ENDPOINTS.VOICE}?GroupId=${GROUP_ID}`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'speech-01-turbo',
                    text: text,
                    stream: false,
                    voice_setting: {
                        voice_id: 'LISHIFU_1',
                        speed: parseFloat(elements.speed.value),
                        vol: parseFloat(elements.volume.value),
                        pitch: parseFloat(elements.pitch.value),
                        emotion: elements.emotion.value
                    },
                    audio_setting: {
                        sample_rate: 32000,
                        bitrate: 128000,
                        format: 'mp3',
                        channel: 1
                    }
                })
            });
            
            if (!response.ok) throw new Error('语音生成失败');
            
            const audioBlob = await response.blob();
            speechSynthesizer.audioBlob = audioBlob;
            
            const audioUrl = URL.createObjectURL(audioBlob);
            elements.audioPlayer.src = audioUrl;
            elements.audioPlayer.load();
            
            utils.showToast('语音生成成功');
            
        } catch (err) {
            utils.showToast(err.message || '语音生成失败', 'error');
        } finally {
            utils.setLoading(elements.generateAudio, false);
        }
    },
    
    // 下载音频
    download: () => {
        if (!speechSynthesizer.audioBlob) {
            utils.showToast('请先生成语音', 'warning');
            return;
        }
        
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        utils.saveFile(speechSynthesizer.audioBlob, `broadcast_${timestamp}.mp3`);
    }
};

// 初始化应用
const app = {
    init: () => {
        // 初始化系统提示词
        promptManager.init();
        
        // 绑定文本处理事件
        elements.generateBtn.addEventListener('click', textProcessor.generate);
        elements.clearInput.addEventListener('click', () => elements.inputText.value = '');
        elements.clearOutput.addEventListener('click', () => elements.outputText.value = '');
        elements.copyOutput.addEventListener('click', () => utils.copyToClipboard(elements.outputText.value));
        
        // 绑定语音控制事件
        elements.generateAudio.addEventListener('click', speechSynthesizer.generate);
        elements.downloadAudio.addEventListener('click', speechSynthesizer.download);
        
        // 绑定语音参数显示
        const rangeInputs = [elements.speed, elements.volume, elements.pitch];
        rangeInputs.forEach(input => {
            const display = input.nextElementSibling;
            input.addEventListener('input', () => {
                display.textContent = parseFloat(input.value).toFixed(1);
            });
        });
    }
};

// 启动应用
document.addEventListener('DOMContentLoaded', app.init);
                    model: 'speech-01-turbo',
                    text: text,
                    stream: false,
                    voice_setting: {
                        voice_id: 'LISHIFU_1',
                        speed: parseFloat(elements.speed.value),
                        vol: parseFloat(elements.volume.value),
                        pitch: parseFloat(elements.pitch.value),
                        emotion: elements.emotion.value
                    },
                    audio_setting: {
                        sample_rate: 32000,
                        bitrate: 128000,
                        format: 'mp3',
                        channel: 1
                    }
                })
            });
            
            if (!response.ok) throw new Error('语音生成失败');
            
            const blob