const express = require('express');
const fetch = require('node-fetch');
const app = express();

// 中间件配置
app.use(express.json());
app.use(express.static('public'));

// 配置CORS
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }
    next();
});

// DeepSeek R1 API配置
const API_KEY = 'a4db67fd-498b-4cc9-a9a6-ff11aaf994df';
const API_URL = 'https://ark.cn-beijing.volces.com/api/v3/chat/completions';

// 处理聊天请求
app.post('/api/chat', async (req, res) => {
    let apiResponse;
    try {
        // 验证请求数据
        if (!req.body.messages || !Array.isArray(req.body.messages)) {
            throw new Error('无效的请求数据格式');
        }

        // 设置响应头，启用流式传输
        res.setHeader('Content-Type', 'text/plain');
        res.setHeader('Transfer-Encoding', 'chunked');

        // 准备请求数据
        apiResponse = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`
            },
            body: JSON.stringify({
                model: 'deepseek-r1-250120',
                messages: req.body.messages,
                temperature: 0.6,
                stream: true
            }),
            timeout: 60000 // 60秒超时
        });

        if (!apiResponse.ok) {
            const errorData = await apiResponse.text();
            throw new Error(`API请求失败: ${apiResponse.status} - ${errorData}`);
        }

        // 处理流式响应
        const reader = apiResponse.body.getReader();
        const decoder = new TextDecoder();

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value);
            res.write(chunk);
        }

        res.end();

    } catch (error) {
        console.error('错误:', error);

        // 如果响应头已经发送，则通过流发送错误消息
        if (res.headersSent) {
            res.write('发生错误: ' + error.message);
            res.end();
        } else {
            // 否则发送标准错误响应
            res.status(500).json({
                error: '服务器错误',
                message: error.message
            });
        }

        // 确保清理API响应资源
        if (apiResponse && apiResponse.body) {
            try {
                await apiResponse.body.cancel();
            } catch (cleanupError) {
                console.error('清理资源时发生错误:', cleanupError);
            }
        }
    }
});

// 健康检查端点
app.get('/health', (req, res) => {
    res.json({ status: 'ok' });
});

// 启动服务器
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`服务器运行在 http://localhost:${PORT}`);
});