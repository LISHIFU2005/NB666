// DOM元素
const chatHistory = document.getElementById('chat-history');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');

// 系统提示信息
const systemMessage = {
    role: 'system',
    content: '你是一位专业的Life Coach，擅长通过对话帮助人们发现自我、克服困难、实现个人成长。你会以同理心倾听用户的问题，提供有针对性的建议和指导。'
};

// 对话历史
let messages = [systemMessage];

// 事件监听器
sendButton.addEventListener('click', handleSendMessage);
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSendMessage();
    }
});

// 处理发送消息
async function handleSendMessage() {
    const userMessage = userInput.value.trim();
    if (!userMessage) return;

    // 禁用输入和按钮
    userInput.disabled = true;
    sendButton.disabled = true;

    // 添加用户消息到界面
    appendMessage('user', userMessage);
    userInput.value = '';

    // 更新消息历史
    messages.push({ role: 'user', content: userMessage });

    try {
        // 创建响应容器
        const aiMessageElement = createMessageElement('ai', '');
        chatHistory.appendChild(aiMessageElement);

        // 发送请求到后端
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ messages })
        });

        if (!response.ok) throw new Error('API请求失败');

        // 处理流式响应
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let aiResponse = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value);
            aiResponse += chunk;
            aiMessageElement.textContent = aiResponse;
            aiMessageElement.scrollIntoView({ behavior: 'smooth' });
        }

        // 更新消息历史
        messages.push({ role: 'assistant', content: aiResponse });

    } catch (error) {
        console.error('错误:', error);
        appendMessage('ai', '抱歉，发生了一些错误，请稍后再试。');
    } finally {
        // 重新启用输入和按钮
        userInput.disabled = false;
        sendButton.disabled = false;
        userInput.focus();
    }
}

// 添加消息到界面
function appendMessage(role, content) {
    const messageElement = createMessageElement(role, content);
    chatHistory.appendChild(messageElement);
    messageElement.scrollIntoView({ behavior: 'smooth' });
}

// 创建消息元素
function createMessageElement(role, content) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', `${role}-message`);
    messageElement.textContent = content;
    return messageElement;
}