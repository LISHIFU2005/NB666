const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const API_KEY = 'c01fd622-614a-42ae-a94a-02ead2cc1e11';
const API_URL = 'https://ark.cn-beijing.volces.com/api/v3/chat/completions';
const MAX_RETRIES = 3;
const RETRY_DELAY = 2000; // 2秒

const server = http.createServer((req, res) => {
    if (req.method === 'GET') {
        // 处理静态文件请求
        const cleanUrl = req.url.split('?')[0];
        const filePath = cleanUrl === '/' ? path.join(__dirname, 'index.html') : path.join(__dirname, cleanUrl);
        const extname = path.extname(filePath);
        const contentType = {
            '.html': 'text/html',
            '.js': 'text/javascript',
            '.css': 'text/css'
        }[extname] || 'text/plain';

        fs.readFile(filePath, (err, content) => {
            if (err) {
                console.error('Error reading file:', filePath, err);
                res.writeHead(404);
                res.end('File not found');
                return;
            }
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(content);
        });
    } else if (req.method === 'POST' && req.url === '/generate-names') {
        // 处理名字生成请求
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            const { englishName } = JSON.parse(body);

            // 构建API请求
            const apiRequestData = {
                model: 'deepseek-r1-250120',
                messages: [
                    {
                        role: 'system',
                        content: '你是一个专业的中文名字生成器，擅长为外国人创造富有传统文化内涵的中文名字。你需要融入以下元素：\n1. 十二生肖的特质和寓意\n2. 聊斋志异中的神秘典故和意境\n3. 中国传统风水学说中的五行相生相克原理\n\n请根据用户提供的英文名，生成3个独特的中文名字。每个名字都应该：\n1. 体现中国传统文化特色\n2. 与英文名的含义建立巧妙联系\n3. 融入生肖、聊斋或风水元素\n4. 提供详细的文化寓意解释'
                    },
                    {
                        role: 'user',
                        content: `请为英文名"${englishName}"生成3个中文名字，每个名字都要融入生肖、聊斋志异或风水文化元素。格式要求：每个名字单独一段，包含：\n- 中文名\n- 拼音\n- 相关的传统文化元素说明（生肖/聊斋/风水）\n- 寓意解释`
                    }
                ]
            };

            const makeRequest = (retryCount = 0) => {
                const apiRequest = https.request(
                    API_URL,
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${API_KEY}`
                        },
                        timeout: 30000 // 30秒超时
                    },
                    apiResponse => {
                        let apiData = '';
                        apiResponse.on('data', chunk => apiData += chunk);
                        apiResponse.on('end', () => {
                            if (apiResponse.statusCode === 200) {
                                res.writeHead(200, {
                                    'Content-Type': 'application/json',
                                    'Access-Control-Allow-Origin': '*'
                                });
                                res.end(apiData);
                            } else if (retryCount < MAX_RETRIES) {
                                setTimeout(() => makeRequest(retryCount + 1), RETRY_DELAY);
                            } else {
                                res.writeHead(500, {
                                    'Content-Type': 'application/json',
                                    'Access-Control-Allow-Origin': '*'
                                });
                                res.end(JSON.stringify({ error: '服务器响应异常，请稍后重试' }));
                            }
                        });
                    }
                );

            apiRequest.on('error', error => {
                if (retryCount < MAX_RETRIES) {
                    setTimeout(() => makeRequest(retryCount + 1), RETRY_DELAY);
                } else {
                    res.writeHead(500, {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    });
                    res.end(JSON.stringify({ error: '网络连接错误，请稍后重试' }));
                }
            });

            apiRequest.on('timeout', () => {
                apiRequest.destroy();
                res.writeHead(504, {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                });
                res.end(JSON.stringify({ error: '请求超时，请稍后重试' }));
            });

            apiRequest.write(JSON.stringify(apiRequestData));
            apiRequest.end();
            };
            
            makeRequest();
        });
    } else if (req.method === 'OPTIONS') {
        // 处理CORS预检请求
        res.writeHead(204, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type'
        });
        res.end();
    } else {
        res.writeHead(404);
        res.end();
    }
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}/`);
});