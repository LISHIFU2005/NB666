async function generateNames() {
    const englishName = document.getElementById('englishName').value.trim();
    const button = document.querySelector('button');
    const loading = document.getElementById('loading');
    const error = document.getElementById('error');
    const results = document.getElementById('results');

    if (!englishName) {
        error.textContent = '请输入英文名';
        error.style.display = 'block';
        return;
    }

    // 重置界面状态
    error.style.display = 'none';
    results.style.display = 'none';
    results.classList.remove('show');
    button.disabled = true;
    loading.style.display = 'block';

    try {
        const response = await fetch('http://localhost:3000/generate-names', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ englishName })
        });

        if (!response.ok) {
            throw new Error('服务器响应错误');
        }

        const data = await response.json();
        if (data.error) {
            throw new Error(data.error);
        }

        // 解析AI返回的内容
        const content = data.choices[0].message.content;
        const nameSegments = content.split('\n\n').filter(segment => segment.trim());

        // 清空并显示结果区域
        results.innerHTML = '';
        nameSegments.forEach(segment => {
            const card = document.createElement('div');
            card.className = 'name-card';
            
            // 提取中文名（假设是段落的第一行）
            const lines = segment.split('\n');
            const chineseName = lines[0];
            
            // 创建名字显示
            const nameDiv = document.createElement('div');
            nameDiv.className = 'chinese-name';
            nameDiv.textContent = chineseName;
            
            // 创建含义解释
            const meaningDiv = document.createElement('div');
            meaningDiv.className = 'meaning';
            meaningDiv.innerHTML = lines.slice(1).join('<br>');
            
            card.appendChild(nameDiv);
            card.appendChild(meaningDiv);
            results.appendChild(card);
        });

        results.style.display = 'block';
        // 添加一个短暂延迟以确保display:block生效后再添加show类
        setTimeout(() => {
            results.classList.add('show');
        }, 10);
    } catch (err) {
        error.textContent = err.message || '生成名字时出错，请稍后重试';
        error.style.display = 'block';
    } finally {
        button.disabled = false;
        loading.style.display = 'none';
    }
}