class Config:
    # 飞书应用配置
    FEISHU_APP_ID = "cli_a7321294a738d01c"
    FEISHU_APP_SECRET = "L4uyDgQNH2xd7yE7A3BXubeTvrSy5dSy"
    
    # 多维表格配置
    BASE_ID = "HrG6bqJf4auKfPsn3cic4VSHnic"
    TABLE_ID = "tblRfPUAZ8ewftUA"
    
    # Flask配置
    DEBUG = True
    SECRET_KEY = "your-secret-key-here"