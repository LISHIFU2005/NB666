from flask import Flask, render_template
import requests
from config import Config
from datetime import datetime, timedelta
from flask_caching import Cache

app = Flask(__name__)
app.config.from_object(Config)

# 配置缓存
cache = Cache(app, config={'CACHE_TYPE': 'simple'})

def get_tenant_access_token():
    """获取飞书tenant_access_token"""
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    headers = {"Content-Type": "application/json"}
    data = {
        "app_id": app.config['FEISHU_APP_ID'],
        "app_secret": app.config['FEISHU_APP_SECRET']
    }
    response = requests.post(url, headers=headers, json=data)
    return response.json().get('tenant_access_token')

@cache.memoize(timeout=7200)
def get_articles():
    """获取飞书多维表格数据"""
    token = get_tenant_access_token()
    url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app.config['BASE_ID']}/tables/{app.config['TABLE_ID']}/records"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        data = response.json()
        articles = []
        for item in data.get('data', {}).get('items', []):
            fields = item.get('fields', {})
            # 处理文章内容中的字典格式文本
            content = fields.get('概要内容输出', '')
            if isinstance(content, str):
                # 处理字典字符串格式
                if content.startswith("{'text': '") and content.endswith("', 'type': 'text'}"):
                    content = content[9:-19]  # 提取实际的文本内容
                # 处理纯文本格式
                elif content.startswith('{"text":"') and content.endswith('"}'):
                    content = content[8:-2]  # 提取实际的文本内容
                # 处理其他可能的格式
                elif content.startswith('{') and content.endswith('}'):
                    try:
                        import json
                        content_dict = json.loads(content)
                        if isinstance(content_dict, dict) and 'text' in content_dict:
                            content = content_dict['text']
                    except:
                        pass  # 保持原始内容

            article = {
                'record_id': item.get('record_id'),
                'title': fields.get('标题', ''),
                'golden_sentence': fields.get('金句输出', ''),
                'comment': fields.get('黄叔点评', ''),
                'content': content
            }
            articles.append(article)
        return articles
    return []

@app.route('/')
def index():
    """首页路由"""
    articles = get_articles()
    return render_template('index.html', articles=articles)

@app.route('/article/<article_id>')
def article_detail(article_id):
    """文章详情页路由"""
    articles = get_articles()
    article = next((a for a in articles if a['record_id'] == article_id), None)
    if article:
        return render_template('detail.html', article=article)
    return '文章不存在', 404

if __name__ == '__main__':
    # 设置UTF-8编码
    import sys
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    app.run(host='0.0.0.0', port=5000)